var token = context.getVariable("google.credentials.tokenType")+" "+context.getVariable("google.credentials.accessToken");
context.setVariable("google.credentials.accessToken", token);